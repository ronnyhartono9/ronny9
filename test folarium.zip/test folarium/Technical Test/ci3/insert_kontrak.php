<form action="/ci3/index.php/kontrak"method="post" >
    

    id Pegawai :
    <select id="idpeg" style="visibility:hidden"> 
        <option> 
                -
        </option> 
      <? 
          include "koneksi.php";       
          $SQL="select id,nama_pegawai from pegawai"; 
          $result = mysqli_query($link,$SQL); 
          while($Row = mysqli_fetch_assoc($result)){
      ?> 
        <option> 
                <?echo $Row["id"]."-".$Row["nama_pegawai"];?> 
        </option> 
       <?} mysqli_close($link);?>   
        <input type="text"name="peg_id"id="id_peg">
    </select><br>

    nama Pegawai :
    <select id="nmpeg"onchange="sel()" >
        <option> 
                -
        </option> 
    <? 
          include "koneksi.php";       
          $SQL="select nama_pegawai from pegawai"; 
          $result = mysqli_query($link,$SQL); 
          while($Row = mysqli_fetch_assoc($result)){
      ?> 
        <option>
           <?echo $Row["nama_pegawai"];?> 
        </option>
    <?} mysqli_close($link); ?>       
    </select><br><br> 


    id jabatan :
    <select id="idjab"style="visibility:hidden" > 
    <option> 
                -
        </option> 
      <? 
          include "koneksi.php";       
          $SQL="select id,nama_jab from jab_pegawai"; 
          $result = mysqli_query($link,$SQL); 
          while($Row = mysqli_fetch_assoc($result)){
      ?> 
        <option> 
                <?echo $Row["id"]."-".$Row["nama_jab"];?> 
        </option> 
       <?} mysqli_close($link);?>   
        <input type="text"name="jab_id"id="id_jab">
    </select><br>

    nama jabatan :
    <select id="nmjab"onchange="sel2()" >
    <option> 
                -
        </option> 
    <? 
          include "koneksi.php";       
          $SQL="select nama_jab from jab_pegawai"; 
          $result = mysqli_query($link,$SQL); 
          while($Row = mysqli_fetch_assoc($result)){
      ?> 
        <option>
           <?echo $Row["nama_jab"];?> 
        </option>
    <?} mysqli_close($link); ?>       
    </select><br><br> 
    

    


    Masa kontrak Pegawai :
    <input type="text"name="masakon"><br>
    jangka kontrak Pegawai :
    <input type="text"name="jangka">
    <input type="submit" value="Save"name="in" >
</form>