<form action="/ci3/index.php/jab_pegawai"method="post" >
    id jab
    <input type="text"value="<?echo $_GET["id"];?>"name="idjab"><BR>

    Nama jabatan :
    <input type="text"name="namajab"value="<?echo $_GET["nm"];?>"> 
    <input type="submit" value="update"name="up" >
</form>