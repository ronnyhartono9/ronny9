<?php

defined('BASEPATH') OR exit('No direct script access allowed');
 
if(isset($_POST["in"])){  //proses insert
    if($_POST["in"] == "Save" ){
        include "koneksi.php"; 
        $SQL="insert into `kontrak`(masa,jangka_waktu,peg_id,jab_id)values('".$_POST["masakon"]."','".$_POST["jangka"]."','".$_POST["peg_id"]."',' ". $_POST["jab_id"] ."' )"; 
        $result = mysqli_query($link,$SQL);mysqli_close($link);
    } 
}

if(isset($_POST["up"])){  //proses update
    if($_POST["up"] == "update" ){ 
        include "koneksi.php"; 
        $SQL="update kontrak 
        set masa = '".$_POST["masakon"]."', jangka_waktu = '".$_POST["jangka"]."' ,peg_id = '".$_POST["peg_id2"]."', jab_id  = '".$_POST["jab_id2"]."'" ." where id = '".$_POST["idkon"]."'"
         
        ; 
        // echo $SQL;
        $result = mysqli_query($link,$SQL);mysqli_close($link);
    } 
}

  
 

 
class kontrak extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model("kontrak_model");
        $this->load->library('form_validation');
    }

    public function index()
    {  
        $data["kontrak"] = $this->kontrak_model->getAll();
        $data["jumlah_hal"] = $this->kontrak_model->jumlah_hal();
        $data["nomer"] = (object) array('1'); 
        $this->load->view("list3", $data);
    }

    public function delete($id=null)
    {
        if (!isset($id)) show_404();       
            if ($this->kontrak_model->delete($id)) {
                $data["kontrak"] = $this->kontrak_model->getAll();
                $data["jumlah_hal"] = $this->kontrak_model->jumlah_hal();
                $data["nomer"] = (object) array('1'); 
                $this->load->view("list3.php", $data);
            }
        
    }

    public function paging($id = null)
    {   
        $data["kontrak"] = $this->kontrak_model->get($id);
        $data["jumlah_hal"] = $this->kontrak_model->jumlah_hal();
        $data["nomer"] = (object) array($id); 
        $this->load->view("list3", $data);
    } 
}