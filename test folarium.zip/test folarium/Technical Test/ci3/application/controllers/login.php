<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class login extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model("login_model");
    }

    public function index()
    {
        $this->load->view('login');	  
    } 

    public function destroyer()
    {
        unset($_SESSION['pesan']);$this->load->view("login");
    }     

    public function proses() // proses login
    {
        $post = $this->input->post();        
        $data = $this->login_model->bukan_dari_db();
        if(isset($post["t"])){
            if( $data == $post["t"]){
                $datauser["muser"] = $this->login_model->dari_table_muser();
                $this->load->view('template/header');
                $this->load->view("muser",$datauser);
                $this->load->view('template/footer');
            }else{
                $_SESSION["pesan"] = "usernya bukan ".$post["t"];          
                $this->load->view("login");
            }
        }else{
            $datauser["muser"] = $this->login_model->dari_table_muser();
            $this->load->view('template/header');
            $this->load->view("muser",$datauser);
            $this->load->view('template/footer');
        }
    }

    public function edituser($id = null)  
    {
        $datauser["muser"] = $this->login_model->dari_table_muser();
        $this->load->view('template/header');
        $this->load->view("muser",$datauser);
        $this->load->view('template/footer');
    }
    
    public function deleteuser($id = null)  
    {
        $datauser["muser"] = $this->login_model->dari_table_muser();
        $this->load->view('template/header');
        $this->load->view("muser",$datauser);
        $this->load->view('template/footer');
    }    
   
}