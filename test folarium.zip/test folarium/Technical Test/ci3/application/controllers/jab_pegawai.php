<?php

defined('BASEPATH') OR exit('No direct script access allowed');
 
if(isset($_POST["in"])){  //proses insert
    if($_POST["in"] == "Save" ){
        include "koneksi.php"; 
        $SQL="insert into `jab_pegawai`(nama_jab)values('".$_POST["namajab"]."')"; 
        $result = mysqli_query($link,$SQL);mysqli_close($link);
    } 
}

if(isset($_POST["up"])){  //proses update
    if($_POST["up"] == "update" ){
        include "koneksi.php"; 
        $SQL="update jab_pegawai set nama_jab = '".$_POST["namajab"]."' where id = '".$_POST["idjab"]."'"; 
        $result = mysqli_query($link,$SQL);mysqli_close($link);
    } 
}


 
class jab_pegawai extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model("jab_pegawai_model");
        $this->load->library('form_validation');
    }

    public function index()
    {  
        $data["jab_pegawai"] = $this->jab_pegawai_model->getAll();
        $data["jumlah_hal"] = $this->jab_pegawai_model->jumlah_hal();
        $data["nomer"] = (object) array('1'); 
        $this->load->view("list2", $data);
    }

    public function delete($id=null)
    {
        if (!isset($id)) show_404();       
            if ($this->jab_pegawai_model->delete($id)) {
                $data["jab_pegawai"] = $this->jab_pegawai_model->getAll();
                $data["jumlah_hal"] = $this->jab_pegawai_model->jumlah_hal();
                $data["nomer"] = (object) array('1'); 
                $this->load->view("list2.php", $data);
            }
        
    }

    public function paging($id = null)
    {   
        $data["jab_pegawai"] = $this->jab_pegawai_model->get($id);
        $data["jumlah_hal"] = $this->jab_pegawai_model->jumlah_hal();
        $data["nomer"] = (object) array($id); 
        $this->load->view("list2", $data);
    } 
}