<?php 
	 
	$link = mysqli_connect("localhost", "root", "", "phptest");
    if (!$link) {die('Something went wrong while connecting to MSSQL');}
    
?>