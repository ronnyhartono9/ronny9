<?php

defined('BASEPATH') OR exit('No direct script access allowed');
 
if(isset($_POST["in"])){  //proses insert
    if($_POST["in"] == "Save" ){
        include "koneksi.php"; 
        $SQL="insert into `pegawai`(nama_pegawai)values('".$_POST["namapeg"]."')"; 
        $result = mysqli_query($link,$SQL);mysqli_close($link);
    } 
}

if(isset($_POST["up"])){  //proses update
    if($_POST["up"] == "update" ){
        include "koneksi.php"; 
        $SQL="update pegawai set nama_pegawai = '".$_POST["namapeg"]."' where id = '".$_POST["idpeg"]."'"; 
        $result = mysqli_query($link,$SQL);mysqli_close($link);
    } 
}


 
class pegawai extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model("pegawai_model");
        $this->load->library('form_validation');
    }

    public function index()
    {  
        $data["pegawai"] = $this->pegawai_model->getAll();
        $data["jumlah_hal"] = $this->pegawai_model->jumlah_hal();
        $data["nomer"] = (object) array('1'); 
        $this->load->view("list", $data);
    }

    public function delete($id=null)
    {
        if (!isset($id)) show_404();       
            if ($this->pegawai_model->delete($id)) {
                $data["pegawai"] = $this->pegawai_model->getAll();
                $data["jumlah_hal"] = $this->pegawai_model->jumlah_hal();
                $data["nomer"] = (object) array('1'); 
                $this->load->view("list.php", $data);
            }
        
    }

    public function paging($id = null)
    {   
        $data["pegawai"] = $this->pegawai_model->get($id);
        $data["jumlah_hal"] = $this->pegawai_model->jumlah_hal();
        $data["nomer"] = (object) array($id); 
        $this->load->view("list", $data);
    } 
}