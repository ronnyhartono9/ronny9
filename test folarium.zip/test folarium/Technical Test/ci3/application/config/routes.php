<?php 
defined('BASEPATH') OR exit('No direct script access allowed'); 
$route['default_controller'] = 'welcome';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;

?>
<script> 
function sel(){ 
    document.getElementById("idpeg").selectedIndex = document.getElementById("nmpeg").selectedIndex;  
     var  myArray = document.getElementById("idpeg").value.split("-"); 
    document.getElementById("id_peg").value =myArray[0]; 
}
function sel2(){ 
    document.getElementById("idjab").selectedIndex = document.getElementById("nmjab").selectedIndex;  
     var  myArray = document.getElementById("idjab").value.split("-"); 
    document.getElementById("id_jab").value =myArray[0]; 
}
function t(){
    var table = document.getElementById("ttb");
    var rows = table.getElementsByTagName("tr");
    var sc = document.getElementById("sc").value;

    if(sc == ""){
        for (var i = 2; i < rows.length; i++) { 
                table.rows[i].style.visibility = 'visible'; 
        } 
    }else{
        for (var i = 2; i < rows.length; i++) { 
                table.rows[i].style.visibility = 'visible'; 
        }  
        for (var i = 2; i < rows.length; i++) {
            if( table.rows[i].cells[0].innerText != sc ){ 
                table.rows[i].style.visibility = 'hidden';
            }
        } 
    }   
}
 
function loadDoc(grace){
    var xhttp = new XMLHttpRequest(); 
    xhttp.onreadystatechange = function(){
    if (this.readyState == 4 && this.status == 200){
        document.getElementById("f").innerHTML=this.responseText; 
        }
    }; 
        xhttp.open("GET",grace,true);xhttp.send();
} 

</script>
<meta name="viewport"content="width=device-width,initial-scale=0.6">

<center>
<div>
    <a href="/ci3/index.php/pegawai"> data pegawai </a> 
    <a href="/ci3/index.php/jab_pegawai"> jabatan pegawai </a> 
    <a href="/ci3/index.php/kontrak"> data kontrak </a> 
</div>
</center>