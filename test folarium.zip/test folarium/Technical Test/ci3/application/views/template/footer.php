<footer class="footer">
	  <div class="container" style="text-align:center;">
	  	<hr/>
        <span>Warung Belajar aaaa @<?php echo date('Y'); ?></span>
        <pre>
          g iso ngene oooo
          https://www.warungbelajar.com/membuat-crud-createread-update-delete-di-codeigniter.html
        </pre>
      </div>
    </footer>
  </body>
</html>