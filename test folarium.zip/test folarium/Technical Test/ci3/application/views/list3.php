<!DOCTYPE html>
<html lang="en">
<head>
</head>
<body id="page-top">
 
	<div id="wrapper">
		<div id="content-wrapper">
			<div class="container-fluid">
				<div class="card mb-3">
					<div class="card-header">					 
						<a onclick="loadDoc('/ci3/insert_kontrak.php')">Add New</a>
					</div>
					<div class="card-body">
						<div class="table-responsive"> 
	                                <center>									
									<?php foreach ($nomer as $num): ?> 	<?php endforeach; ?>
										<Strong>Data Kontrak Pegawai <br></strong>
									ini halaman <?  echo $num; ?>
						            <table  style="width:10%;">
										<tr>
										<?php foreach ($jumlah_hal as $jl): ?> 	<?php endforeach; ?>
                                                <?php 
												    for($i=1;$i<=$jl->jl;$i++){ ?>
														<td style="text-align:center"> 
															<a href="/ci3/index.php/kontrak/paging/<?echo $i;?>">
																<?php echo $i; ?> 
															</a> 
														</td>
												<?php }?>
										</tr> 
									</table>
									</center>

									<div style="width:300px;height:300px;background:beige"id="f">


									</div>

							<table id="ttb"border=1 class="table table-hover" id="dataTable" width="100%" cellspacing="0">								 
								    <tr colspan=2>
										<th>Filter <input type="text"id="sc"> <a onclick=t() >cari </a> </th> 
									</tr>
									<tr colspan=2>
										<th>Masa</th> 
										<th>jangka waktu</th> 
										<!-- <th>peg_id</th> 
										<th>jab_id</th>  -->
										<th>pegawai</th> 
										<th>jabatan</th> 
									</tr>
									<?php foreach ($kontrak as $kon): ?>
									<tr>
										<td width="150">
											<?php echo $kon->masa ?>
										</td>		
										<td width="150">
											<?php echo $kon->jangka_waktu ?>
										</td>
										<!-- <td width="150">
											<?php //echo $kon->peg_id ?>
										</td>
										<td width="150">
											<?php //echo $kon->jab_id ?>
										</td> -->
										<td width="150">
											<?php echo $kon->nama_pegawai ?>
										</td>
										<td width="150">
											<?php echo $kon->nama_jab ?>
										</td>
										<td width="250">
											 <a onclick="loadDoc('/ci3/edit_kontrak.php?id=<? echo $kon->id;?>&nm=<?echo $kon->masa;?>&jk=<?echo $kon->jangka_waktu;?> &peg_id=<?echo $kon->peg_id;?> &jab_id=<?echo $kon->jab_id;?>           ')">Edit</a>
											 <a href=" <?   echo "/ci3/index.php/kontrak/delete/".$kon->id; ?>">Hapus</a>
										</td>
									</tr>
									<?php endforeach; ?>
							</table>
						</div>
					</div>
				</div> 
			</div> 
		</div> 
	</div>  
</body>

</html>