<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<br>
<? 
  if(isset($_SESSION["pesan"])){
	echo "Session = ".$_SESSION["pesan"];
  } 
?>
<a onclick="t()">kok lho</a> 
<form action="<?php echo '/ci3/index.php/login/proses' ?>" method="post">
     <input type="text"name="t">
	 <input type="submit"value="login"name="test">
</form>
<br>
<form action="<?php echo '/ci3/index.php/login/destroyer' ?>" method="post">     
	 <input type="submit"value="Destroy All"name="d">
</form>
</body>
</html>