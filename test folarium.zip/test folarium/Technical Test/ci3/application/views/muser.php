<main role="main" class="container">
		<div class="card">
			<div class="card-header">Data User</div>
			<div class="card-body">
         <a href="/ci3/index.php/login/adduser" class="btn btn-success">Add New</a>
				<br/>
				<br/>
				<table class="table table-bordered">
					<tr>
                                  <th>User ID</th>
                                  <th>User Key</th>
                                  <th>Action</th>
					</tr>
                            <?php foreach ($muser as $mu): ?>
                            <tr>
                                <td width="150">
                                    <?php echo $mu->userID ?>
                                </td>
                                <td>
                                    <?php echo $mu->userKey ?>
                                </td> 
                                <td width="250">										
                                     <a href=" <?   echo "/ci3/index.php/login/edituser/".$mu->nRowID;  ?> "class="btn btn-warning">Edit</a>
                                     <a href=" <?   echo "/ci3/index.php/login/deleteuser/".$mu->nRowID; ?>"class="btn btn-danger">Hapus</a>
                                </td>
                            </tr>
                            <?php endforeach; ?>

				</table>
			</div>
		</div>
</main>