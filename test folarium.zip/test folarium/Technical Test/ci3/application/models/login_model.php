<?php defined('BASEPATH') OR exit('No direct script access allowed');

class login_model extends CI_Model
{
    private $_table = "muser";

    /*public $product_id;
    public $name;
    public $price;
    public $image = "default.jpg";
    public $description;*/

    public function bukan_dari_db(){
        return 'Ronny';
    }

    public function dari_table_muser()
    { 
        return $this->db->get($this->_table)->result();
       
    } 
   
}