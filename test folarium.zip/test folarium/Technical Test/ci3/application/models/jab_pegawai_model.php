<?php defined('BASEPATH') OR exit('No direct script access allowed');

class jab_pegawai_model extends CI_Model
{
    private $_table = "jab_pegawai";
    public $product_id;
    public $name;
    public $price;
    public $image = "default.jpg";
    public $description;
    public function rules()
    {
        return [
            ['field' => 'name',
            'label' => 'Name',
            'rules' => 'required'],

            ['field' => 'price',
            'label' => 'Price',
            'rules' => 'numeric'],
            
            ['field' => 'description',
            'label' => 'Description',
            'rules' => 'required']
        ];
    }

    public function jumlah_hal(){
       $this->db->select('CEILING(count(*) / 6) as jl');
       $this->db->from('jab_pegawai');
       $query = $this->db->get();
       return $query->result();  
    }

    public function getAll()
    {  
            $this->db->select('*');
            $this->db->from('jab_pegawai');
            $this->db->limit(6);
            $this->db->order_by("id asc");
            $query = $this->db->get();
            return $query->result(); 
    }

    public function get($id)
    {  
            $this->db->select('*');
            $this->db->from('jab_pegawai');
            $this->db->limit(6);
            $this->db->offset($id * 6 - 6);
            $this->db->order_by("id asc");
            $query = $this->db->get();
            return $query->result(); 
    } 

    public function delete($id)
    {
        return $this->db->delete($this->_table, array("id" => $id));
    }
}