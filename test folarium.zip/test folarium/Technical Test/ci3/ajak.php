<form action="/ci3/index.php/pegawai"method="post" >
    Nama Pegawai :
    <input type="text"name="namapeg"> 
    <input type="submit" value="Save"name="in" >
</form>