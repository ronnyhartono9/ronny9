<form action="/ci3/index.php/jab_pegawai"method="post" >
    Jabatan Pegawai :
    <input type="text"name="namajab"> 
    <input type="submit" value="Save"name="in" >
</form>