<form action="/ci3/index.php/kontrak"method="post" >
     
    id Pegawai :
    <select id="idpeg"style="visibility:hidden" > 
    <option> 
                -
        </option> 
      <? 
          include "koneksi.php";       
          $SQL="select id,nama_pegawai from pegawai"; 
          $result = mysqli_query($link,$SQL); 
          while($Row = mysqli_fetch_assoc($result)){
      ?> 
        <option> 
                <?echo $Row["id"]."-".$Row["nama_pegawai"];?> 
        </option> 
       <?} mysqli_close($link);?>   
        <input type="text"name="peg_id2"id="id_peg" value = <? echo $_GET["peg_id"];  ?>>
    </select><br>

    nama Pegawai :
    <select id="nmpeg"onchange="sel()">
    <option> 
                -
        </option> 
    <? 
          include "koneksi.php";       
          $SQL="select nama_pegawai from pegawai"; 
          $result = mysqli_query($link,$SQL); 
          while($Row = mysqli_fetch_assoc($result)){
      ?> 
        <option>
           <?echo $Row["nama_pegawai"];?> 
        </option>
    <?} mysqli_close($link); ?>       
    </select><br><br> 


    id jabatan :
    <select id="idjab" style="visibility:hidden"> 
    <option> 
                -
        </option> 
      <? 
          include "koneksi.php";       
          $SQL="select id,nama_jab from jab_pegawai"; 
          $result = mysqli_query($link,$SQL); 
          while($Row = mysqli_fetch_assoc($result)){
      ?> 
        <option> 
                <?echo $Row["id"]."-".$Row["nama_jab"];?> 
        </option> 
       <?} mysqli_close($link);?>   
        <input type="text"name="jab_id2"id="id_jab"  value = <? echo $_GET["jab_id"];  ?> >
    </select><br>

    nama jabatan :
    <select id="nmjab"onchange="sel2()">
    <option> 
                -
        </option> 
    <? 
          include "koneksi.php";       
          $SQL="select nama_jab from jab_pegawai"; 
          $result = mysqli_query($link,$SQL); 
          while($Row = mysqli_fetch_assoc($result)){
      ?> 
        <option>
           <?echo $Row["nama_jab"];?> 
        </option>
    <?} mysqli_close($link); ?>       
    </select><br><br> 
      

    <!-- id kontrak  -->
    <input type="text"value="<?echo $_GET["id"];?>"name="idkon"style="visibility:hidden"><BR>


    <input type="text"name="peg_id"style="visibility:hidden"><br>
    <input type="text"name="jab_id"style="visibility:hidden"><br>

    masa kontrak :
    <input type="text"name="masakon"value="<?echo $_GET["nm"];?>"> <br>
    jangka kontrak :
    <input type="text"name="jangka"value="<?echo $_GET["jk"];?>">
    <input type="submit" value="update"name="up" >
</form>