<form action="/ci3/index.php/pegawai"method="post" >
    id pegawai
    <input type="text"value="<?echo $_GET["id"];?>"name="idpeg"><BR>

    Nama Pegawai :
    <input type="text"name="namapeg"value="<?echo $_GET["nm"];?>"> 
    <input type="submit" value="update"name="up" >
</form>