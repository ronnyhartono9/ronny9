-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 15, 2022 at 01:36 AM
-- Server version: 10.3.16-MariaDB
-- PHP Version: 7.3.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tokobuah`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_special` (IN `pr1` VARCHAR(120), IN `action` VARCHAR(12))  NO SQL
IF ACTION='biasa' THEN
	 SELECT * FROM muser;
ELSEIF ACTION='special' THEN
    SELECT * FROM specialprod;
END IF$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `muser`
--

CREATE TABLE `muser` (
  `userID` varchar(15) CHARACTER SET utf8 NOT NULL,
  `userKey` varchar(64) CHARACTER SET utf8 NOT NULL,
  `userStatus` tinyint(4) NOT NULL,
  `userGroupRowID` decimal(18,0) NOT NULL,
  `nRowID` int(6) UNSIGNED NOT NULL,
  `dLoginTime` datetime DEFAULT NULL,
  `dLogoutTime` datetime DEFAULT NULL,
  `nLoginStatus` tinyint(4) NOT NULL,
  `nNIK` decimal(18,0) DEFAULT NULL,
  `cFullName` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `userManagerID` varchar(15) DEFAULT NULL,
  `cGUID` char(36) NOT NULL,
  `TRANKINDID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `muser`
--

INSERT INTO `muser` (`userID`, `userKey`, `userStatus`, `userGroupRowID`, `nRowID`, `dLoginTime`, `dLogoutTime`, `nLoginStatus`, `nNIK`, `cFullName`, `userManagerID`, `cGUID`, `TRANKINDID`) VALUES
('RONNY', 'ronny', 1, '1', 9, NULL, NULL, 0, NULL, 'ronny hartono', NULL, 'F06CFC1B-7604-4FE6-AABB-E4087D2D15F0', 5),
('CB1', '', 1, '1', 58, NULL, NULL, 0, NULL, NULL, NULL, '6B1EC771-918A-4E2C-9598-5FBE02B6FE59', 5);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `product_id` varchar(64) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` int(11) NOT NULL,
  `image` varchar(255) NOT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`product_id`, `name`, `price`, `image`, `description`) VALUES
('620ae4433081a', 'a', 12, 'default.jpg', 'a');

-- --------------------------------------------------------

--
-- Table structure for table `specialprod`
--

CREATE TABLE `specialprod` (
  `product_id` varchar(64) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` int(11) NOT NULL,
  `image` varchar(255) NOT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `specialprod`
--

INSERT INTO `specialprod` (`product_id`, `name`, `price`, `image`, `description`) VALUES
('620ac522195c4', '0', 12, 'default.jpg', 'a'),
('620ac971ccd5e', '0', 12, 'default.jpg', 'b');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `muser`
--
ALTER TABLE `muser`
  ADD PRIMARY KEY (`nRowID`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `specialprod`
--
ALTER TABLE `specialprod`
  ADD PRIMARY KEY (`product_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `muser`
--
ALTER TABLE `muser`
  MODIFY `nRowID` int(6) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=59;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
