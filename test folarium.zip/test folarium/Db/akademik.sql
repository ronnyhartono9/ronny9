-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 08, 2022 at 05:32 AM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `akademik`
--

-- --------------------------------------------------------

--
-- Table structure for table `mahasiswa`
--

CREATE TABLE `mahasiswa` (
  `nim` varchar(10) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `ipk` float(4,2) NOT NULL,
  `jurusan` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `mahasiswa`
--

INSERT INTO `mahasiswa` (`nim`, `nama`, `ipk`, `jurusan`) VALUES
('075410099', 'Noprianto', 4.00, 'Teknologi Informasi'),
('075410100', 'Noureen Akhlema Shannum', 4.00, 'Pendidikan Bahasa Inggris'),
('075410101', 'Uwais Al-Qarny', 3.99, 'Teknik Sipil'),
('666', '555', 3.99, 'Teknik Informatika');

-- --------------------------------------------------------

--
-- Table structure for table `md_loc0_country`
--

CREATE TABLE `md_loc0_country` (
  `country_id` int(11) NOT NULL,
  `country_name` varchar(30) CHARACTER SET utf8 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `md_loc0_country`
--

INSERT INTO `md_loc0_country` (`country_id`, `country_name`) VALUES
(1, 'Indonesia'),
(2, 'Singapura'),
(3, 'Hogkong'),
(4, 'India');

-- --------------------------------------------------------

--
-- Table structure for table `md_loc2_city`
--

CREATE TABLE `md_loc2_city` (
  `city_id` int(11) NOT NULL,
  `prov_id` int(11) DEFAULT NULL,
  `city_name` varchar(30) CHARACTER SET utf8 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `md_loc2_city`
--

INSERT INTO `md_loc2_city` (`city_id`, `prov_id`, `city_name`) VALUES
(1, 1, 'cilegon'),
(2, 1, 'tangerang'),
(3, 1, 'tangerang selatan'),
(4, 2, 'bandung'),
(5, 2, 'bekasi'),
(6, 2, 'bogor'),
(7, 3, 'semarang'),
(8, 3, 'magelang'),
(9, 3, 'batang'),
(10, 5, 'madiun'),
(11, 5, 'surabaya'),
(12, 4, 'sleman'),
(13, 4, 'kota Yogyakarta'),
(14, 4, 'bantul'),
(15, 6, 'jakarta utara'),
(16, 6, 'jakarta selatan'),
(17, 6, 'jakarta pusat');

-- --------------------------------------------------------

--
-- Table structure for table `md_locl_province`
--

CREATE TABLE `md_locl_province` (
  `prov_id` int(11) NOT NULL,
  `country_id` int(11) DEFAULT NULL,
  `prov_name` varchar(30) CHARACTER SET utf8 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `md_locl_province`
--

INSERT INTO `md_locl_province` (`prov_id`, `country_id`, `prov_name`) VALUES
(1, 1, 'Banten'),
(2, 1, 'Jawa Barat'),
(3, 1, 'Jawa Tengah'),
(4, 1, 'Yogyakarta'),
(5, 1, 'Jawa Timur'),
(6, 1, 'DKI Jakarta');

-- --------------------------------------------------------

--
-- Table structure for table `md_profession0`
--

CREATE TABLE `md_profession0` (
  `profs_id` int(11) NOT NULL,
  `profs_name` varchar(30) CHARACTER SET utf8 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `md_profession0`
--

INSERT INTO `md_profession0` (`profs_id`, `profs_name`) VALUES
(1, 'sales & marketing'),
(2, 'finance & accounting'),
(3, 'human resource'),
(4, 'software enginerring');

-- --------------------------------------------------------

--
-- Table structure for table `mg_company0`
--

CREATE TABLE `mg_company0` (
  `co_id` int(11) NOT NULL,
  `city_id` int(11) DEFAULT NULL,
  `co_name` varchar(30) CHARACTER SET utf8 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `mg_company0`
--

INSERT INTO `mg_company0` (`co_id`, `city_id`, `co_name`) VALUES
(1, 3, 'pt. abc indonesia'),
(2, 11, 'pt klm indonesia'),
(3, 14, 'pt xyz indonesia'),
(4, 1, 'pt hij indonesia'),
(5, 6, 'pt wxy indonesia'),
(6, 13, 'pt ors indonesia'),
(7, 16, 'pt def indonesia'),
(8, 16, 'pt ghi indonesia'),
(9, 17, 'pt cde indonesia');

-- --------------------------------------------------------

--
-- Table structure for table `mg_jobs0`
--

CREATE TABLE `mg_jobs0` (
  `jobs_id` int(11) NOT NULL,
  `profs_id` int(11) DEFAULT NULL,
  `co_id` int(11) DEFAULT NULL,
  `city_id` int(11) DEFAULT NULL,
  `jobs_title` varchar(30) CHARACTER SET utf8 DEFAULT NULL,
  `jobs_register` datetime DEFAULT NULL,
  `jobs_sts` tinyint(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `mg_jobs0`
--

INSERT INTO `mg_jobs0` (`jobs_id`, `profs_id`, `co_id`, `city_id`, `jobs_title`, `jobs_register`, `jobs_sts`) VALUES
(1, 2, 1, 17, 'admin keuangan', '2022-01-30 11:51:16', 1),
(2, 2, 7, 3, 'fa manager', '2022-01-30 11:51:16', 1),
(3, 4, 1, 17, 'system analyst', '2022-01-30 17:54:35', NULL),
(4, 1, 3, 13, 'sales promotion', '2022-01-30 17:54:35', 1),
(5, 1, 4, 11, 'sales supervisor', '2022-01-30 17:54:35', 1);

-- --------------------------------------------------------

--
-- Table structure for table `mg_jobsl_apply`
--

CREATE TABLE `mg_jobsl_apply` (
  `joply_id` int(11) NOT NULL,
  `jobs_id` int(11) DEFAULT NULL,
  `city_id` int(11) DEFAULT NULL,
  `joply_name` varchar(30) CHARACTER SET utf8 DEFAULT NULL,
  `joply_register` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `mg_jobsl_apply`
--

INSERT INTO `mg_jobsl_apply` (`joply_id`, `jobs_id`, `city_id`, `joply_name`, `joply_register`) VALUES
(1, 2, 9, 'joni haryadi', '2022-01-30 17:59:20'),
(2, 1, 11, 'anisa handayani', '2022-01-30 17:59:20'),
(3, 4, 12, 'tirta sista', '2022-01-30 17:59:20'),
(4, 5, 12, 'hendra arwandi', '2022-01-30 17:59:20'),
(5, 5, 3, 'joko cahyono', '2022-01-30 17:59:20'),
(6, 2, 10, 'nisa ninatun', '2022-01-30 17:59:20');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `mahasiswa`
--
ALTER TABLE `mahasiswa`
  ADD PRIMARY KEY (`nim`);

--
-- Indexes for table `md_loc0_country`
--
ALTER TABLE `md_loc0_country`
  ADD PRIMARY KEY (`country_id`);

--
-- Indexes for table `md_loc2_city`
--
ALTER TABLE `md_loc2_city`
  ADD PRIMARY KEY (`city_id`);

--
-- Indexes for table `md_locl_province`
--
ALTER TABLE `md_locl_province`
  ADD PRIMARY KEY (`prov_id`);

--
-- Indexes for table `md_profession0`
--
ALTER TABLE `md_profession0`
  ADD PRIMARY KEY (`profs_id`);

--
-- Indexes for table `mg_company0`
--
ALTER TABLE `mg_company0`
  ADD PRIMARY KEY (`co_id`);

--
-- Indexes for table `mg_jobs0`
--
ALTER TABLE `mg_jobs0`
  ADD PRIMARY KEY (`jobs_id`);

--
-- Indexes for table `mg_jobsl_apply`
--
ALTER TABLE `mg_jobsl_apply`
  ADD PRIMARY KEY (`joply_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `md_loc0_country`
--
ALTER TABLE `md_loc0_country`
  MODIFY `country_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `md_loc2_city`
--
ALTER TABLE `md_loc2_city`
  MODIFY `city_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `md_locl_province`
--
ALTER TABLE `md_locl_province`
  MODIFY `prov_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `md_profession0`
--
ALTER TABLE `md_profession0`
  MODIFY `profs_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `mg_company0`
--
ALTER TABLE `mg_company0`
  MODIFY `co_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `mg_jobs0`
--
ALTER TABLE `mg_jobs0`
  MODIFY `jobs_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `mg_jobsl_apply`
--
ALTER TABLE `mg_jobsl_apply`
  MODIFY `joply_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
