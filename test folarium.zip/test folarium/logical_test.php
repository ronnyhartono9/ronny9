<?  
    function prima(){
      echo "<strong>"."Deret bilangan Prima "."</strong>"."<br>";
      echo "2"." ";
        for($i = 1;$i<=100;$i++)
        {
            if(  $i % 2 != 0   ){ 
              $faktor = 0;
              for($j = 1;$j<=$i;$j++){
                if(   $i %    $j == 0      ){$faktor++;} 
              } 
              if($faktor==2){echo $i." "; }
            }
        }      
    }

    function ganjil(){
      echo "<strong>"."Deret bilangan Ganjil "."</strong>"."<br>";
      for($i = 1;$i<=100;$i++)
      {
          if(  $i % 2 != 0   ){ 
            echo $i." "; 
          }
      }
    }

    function genap(){
      echo "<strong>"."Deret bilangan Genap "."</strong>"."<br>";
      for($i = 1;$i<=100;$i++)
      {
          if(  $i % 2 == 0   ){ 
            echo $i." "; 
          }
      }
    }

    function fibonaci(){
      echo "<strong>"."Deret bilangan fibonaci "."</strong>"."<br>";
      $a=1;$b=1;$c=$a+$b;
      echo $a." ".$b." ".$c." ";
        for($i = 3;$i<=100;$i++)
        {
           $a = $b; $b=$c; $c = $a+$b;
           echo $c." "; 
        }

    }

    function segitigasiku(){
      echo "<strong>"."Segitiga siku-siku "."</strong>"."<br>";
      for($i = 1;$i<=5;$i++)
      {
        for($j = 1;$j<=$i;$j++){
          echo "*";
        }
        echo "<br>";
      }
    }

    function random(){ 
      echo "<strong>"."Random (1-100) "."</strong>"."<br>"; 
      $r=1;
        while($r %  5 != 0 ) {
          $r = rand(1,100); 
         } 
        if( $r <= 60){ 
          echo "<strong>".$r." kurang"."</strong>"."<br>";
        }
        else if( $r>60 &&  $r<=70 ){
          echo "<strong>".$r." cukup"."</strong>"."<br>";
        }
        else if( $r>70 &&  $r<=80 ){
          echo "<strong>".$r." baik"."</strong>"."<br>";
        }
        else{
          echo "<strong>".$r." Luar Biasa"."</strong>"."<br>";
        } 
    }

    function kelipatan3(){
      echo "<strong>"."Deret Kelipatan 3"."</strong>"."<br>";
      for($i = 1;$i<=100;$i++)
      {
          if(  $i % 3 == 0   ){ 
            echo $i." "; 
          }
      }
    }

    function cek_kota($s) {
      echo "<strong>"."kota ".$s." </strong>"."<br>";
        $arr = array(“Jakarta”, “Yogyakarta”, ”Bandung”, ”Bogor”, “Semarang”);
        $ketemu = false;
        if (in_array($s, $arr))
        {$ketemu = true; }
        echo $ketemu;
      } 
      prima();  echo "<br>";
      ganjil();echo "<br>";
      genap();echo "<br>";
      fibonaci();echo "<br>";
      segitigasiku();echo "<br>";
      random();echo "<br>";
      kelipatan3();echo "<br>";
      cek_kota(“Jakarta”);
?>