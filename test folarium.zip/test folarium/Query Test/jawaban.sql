 

#########soal no 1 dan 2
#####
SELECT a.jobs_id ,b.jobs_title AS'judul lowongan',COUNT(a.jobs_id) AS 'jumlah_pelamar'
FROM mg_jobsl_apply a, mg_jobs0 b
WHERE a.jobs_id = b.jobs_id 
GROUP BY jobs_id  

HAVING COUNT(a.jobs_id) = (
 SELECT COUNT(*) AS 'jumlah_pelamar'
FROM mg_jobsl_apply a  
GROUP BY jobs_id
ORDER BY COUNT(*) DESC
 LIMIT 1 
)


#########soal no 3
#####tampilkan judul lowongan dan jumlah pelamar yang tidak dapat pelamar
 SELECT  jobs_title AS 'judul lowongan', 0 AS 'jumlah pelamar'
FROM   mg_jobs0 
WHERE jobs_id  NOT IN (
SELECT jobs_id
FROM mg_jobsl_apply  
)

#########soal no 4
#####tampilkan rata2 jumlah pelamar dari lowongan keseluruhan
SELECT COUNT(*) AS 'jumlah lowongan' , SUM(jumlah_pelamar) AS 'jumlah pelamar', SUM(jumlah_pelamar) / COUNT(*) AS 'rata-rata jumlah pelamar'  FROM
(
	SELECT a.jobs_id ,b.jobs_title AS'judul lowongan',COUNT(a.jobs_id) AS 'jumlah_pelamar'
	FROM mg_jobs0 b 
	LEFT JOIN mg_jobsl_apply a
	ON  a.jobs_id = b.jobs_id
	GROUP BY jobs_id
) AS t

 #########soal no 5
 #####tampilkan rata2 kota dari lowongan keseluruhan   
 
 SELECT  b.jobs_title AS'judul lowongan', c.city_name
FROM mg_jobsl_apply a, mg_jobs0 b , md_loc2_city c
WHERE a.jobs_id = b.jobs_id  
AND c.city_id = b.city_id  
ORDER BY b.jobs_title
 
  #########soal no 6
  #####tampilkan judul lowongan yang huruf depannya ‘f’
  SELECT  b.*
FROM   mg_jobs0 b
WHERE b.jobs_title LIKE 'f%'
 
  #########soal no 7
  #####tampilkan judul lowongan yang huruf terakhir ‘n’
  SELECT  b.*
FROM   mg_jobs0 b
WHERE b.jobs_title LIKE '%n'

  #########soal no 8
  #####tampilkan judul lowongan yang mengandung huruf ‘p’

SELECT  b.*
FROM   mg_jobs0 b
WHERE b.jobs_title LIKE '%p%'
 
  #########soal no 9
  #####tampilkan judul lowongan dengan jumlah pelamar terbesar dan nama pelamar mengandung huruf ‘e’  
  
    SELECT * FROM (     
  
	SELECT a.jobs_id ,b.jobs_title AS'judul lowongan'
	,(
	
	SELECT joply_name FROM  mg_jobsl_apply WHERE joply_name LIKE '%e%' AND mg_jobsl_apply.jobs_id = a.jobs_id
	)
	AS 'pelamar'
	,COUNT(a.jobs_id) AS 'jumlah_pelamar'
	FROM mg_jobsl_apply a, mg_jobs0 b
	WHERE a.jobs_id = b.jobs_id  
	GROUP BY jobs_id  

	HAVING COUNT(a.jobs_id) = (
	 SELECT COUNT(*) AS 'jumlah_pelamar'
	FROM mg_jobsl_apply a  
	GROUP BY jobs_id
	ORDER BY COUNT(*) DESC
	 LIMIT 1 
	)

  ) AS t
  WHERE t.pelamar IS NOT NULL
  #########soal no 10
  #####tampilkan judul lowongan dengan jumlah pelamar terkecil mengandung huruf ‘o’
  
   SELECT * FROM (   
        SELECT a.jobs_id ,b.jobs_title AS'judul lowongan'
	,(
	
	SELECT joply_name FROM  mg_jobsl_apply WHERE joply_name LIKE '%o%' AND mg_jobsl_apply.jobs_id = a.jobs_id
	)
	AS 'pelamar'
	,COUNT(a.jobs_id) AS 'jumlah_pelamar'
	FROM mg_jobsl_apply a, mg_jobs0 b
	WHERE a.jobs_id = b.jobs_id  
	GROUP BY jobs_id   
	
	HAVING COUNT(a.jobs_id) = (
	 SELECT COUNT(*) AS 'jumlah_pelamar'
	FROM mg_jobsl_apply a  
	GROUP BY jobs_id
	ORDER BY COUNT(*) ASC
	 LIMIT 1 
	)
  
  ) AS t
  WHERE t.pelamar IS NOT NULL
  
  
  #########soal no 11 
  #####tampilkan judul lowongan, penempatan lowongan dan perusahaan
	SELECT  a.jobs_title AS 'judul lowongan',  b.city_name AS 'penempatan'  ,c.co_name AS 'perusahaan'
	FROM   mg_jobs0 a,md_loc2_city b,mg_company0 c
	WHERE a.co_id = c.co_id AND a.city_id = b.city_id
	 
  #########soal no 12
  #####tampilkan judul lowongan yang perusahaannya berasal dari provinsi jawa tengah
   SELECT * FROM (
	SELECT  a.jobs_title AS 'judul lowongan',  b.city_name AS 'penempatan'  ,c.co_name AS 'perusahaan'
	,(
		 SELECT b1.city_name
		 FROM md_loc2_city b1,mg_company0 c1
		 WHERE b1.city_id = c1.city_id AND c1.co_name = c.co_name
	) AS 'asal_perusahaan'
	FROM   mg_jobs0 a,md_loc2_city b
	,mg_company0 c
	WHERE a.co_id = c.co_id AND a.city_id = b.city_id 
	
    ) AS t
    WHERE t.asal_perusahaan = 'jawa tengah'
    
  #########soal no 13  tampilkan judul lowongan yang perusahaannya bukan berasal dari negara yang tidak mengandung huruf ‘o’
  #####tampilkan judul lowongan yang perusahaannya bukan berasal dari negara yang tidak mengandung huruf ‘o’

   SELECT * FROM (
	SELECT  a.jobs_title AS 'judul lowongan',  b.city_name AS 'penempatan'  ,c.co_name AS 'perusahaan'
	,(
		 SELECT mdo.country_name  
		 FROM md_loc2_city b1,mg_company0 c1, md_locl_province mp, md_loc0_country mdo
		 WHERE b1.city_id = c1.city_id AND c1.co_name = c.co_name
		 AND mp.prov_id = b1.prov_id AND mp.country_id = mdo.country_id
	) AS 'negara_perusahaan'
	FROM   mg_jobs0 a,md_loc2_city b
	,mg_company0 c
	WHERE a.co_id = c.co_id AND a.city_id = b.city_id  
    ) AS t
   WHERE negara_perusahaan  IN (
    SELECT country_name FROM md_loc0_country WHERE country_name LIKE '%o%')
	
  #########soal no 14
 #####tampilkan judul lowongan dan perusahaan yang memiliki pelamar terbanyak

SELECT a.jobs_id ,b.jobs_title AS'judul lowongan', c.co_name , COUNT(a.jobs_id) AS 'jumlah_pelamar'
FROM mg_jobsl_apply a, mg_jobs0 b, mg_company0 C
WHERE a.jobs_id = b.jobs_id AND C.CO_ID	= b.co_id
GROUP BY jobs_id  

HAVING COUNT(a.jobs_id) = (
 SELECT COUNT(*) AS 'jumlah_pelamar'
FROM mg_jobsl_apply a  
GROUP BY jobs_id
ORDER BY COUNT(*) DESC
 LIMIT 1 
)	
  #########soal no 15 
  ##### tampilkan nama perusahaan yang tidak memiliki lowongan
  SELECT *
  FROM mg_company0
  WHERE co_id NOT IN(
    SELECT co_id
    FROM mg_jobs0
  
  )
  
    #########soal no 16 
    #####tampilkan nama perusahaan yang paling banyak memiliki lowongan 
    SELECT a.jobs_title,a.co_id,b.co_name,COUNT(*)
    FROM mg_jobs0 a, mg_company0 b
    WHERE b.co_id = a.co_id
    GROUP BY a.co_id
    ORDER BY COUNT(*) DESC
    LIMIT 1
    
    
    
    #tampilkan nama perusahaan yang memiliki lowongan dengan profesi “sales”
    #########soal no 17
     
    SELECT b.co_name,a.jobs_title, c.profs_name
    FROM mg_jobs0 a, mg_company0 b , md_profession0 c
    WHERE b.co_id = a.co_id
    AND a.profs_id = c.profs_id
    AND c.profs_name LIKE '%sales%'
    
    #18. tampilkan nama profesi yang perusahaan berasal dari provinsi “Jakarta”
    #########soal no 18 
    
        SELECT c.profs_name ,b.co_name, e.prov_name 
    FROM mg_jobs0 a, mg_company0 b , md_profession0 c , md_loc2_city  d, md_locl_province e
    WHERE b.co_id = a.co_id
    AND a.profs_id = c.profs_id
    AND b.city_id = d.city_id AND d.prov_id = e.prov_id
    AND e.prov_name ="jakarta"
    
    
	#19. Tampilkan jumlah lowongan dari masing2 perusahaan
	#########soal no 19
		    SELECT b.co_name,COUNT(*)
		    FROM mg_jobs0 a, mg_company0 b
		    WHERE b.co_id = a.co_id
		    GROUP BY a.co_id
		    ORDER BY COUNT(*) DESC 
		    
	
	#20. Tampilkan jumlah pelamar dari masing2 perusahaan
	#########soal no 20
	     
	     /*select b.co_name,a.jobs_title, c.joply_name
	     from mg_company0 b, mg_jobs0 a , mg_jobsl_apply c
	     where b.co_id = a.co_id 
	     and c.jobs_id = a.jobs_id
	     order by b.co_name*/
	     
	     SELECT b.co_name, COUNT(*)
	     FROM mg_company0 b, mg_jobs0 a , mg_jobsl_apply c
	     WHERE b.co_id = a.co_id 
	     AND c.jobs_id = a.jobs_id
	     
	     GROUP BY b.co_name
	     
	     
	#21. Tampilkan perusahaan yang tidak punya lowongan
	#########soal no 21 
		 SELECT *
		 FROM 	mg_company0 b	 
		 WHERE co_id NOT IN(
				   
			       SELECT co_id
			       FROM mg_jobs0 a
			)
			
			
	#22. Tampilkan perusahaan yang memiliki pelamar terbanyak
	#########soal no 22
	SELECT *
	FROM (
		    SELECT b.co_name , a.jobs_title,
		    (
		      SELECT COUNT(*)
		      FROM mg_jobsl_apply aa 
		      WHERE aa.jobs_id = a.jobs_id
		    )  AS jumlah_pelamar
		    FROM mg_jobs0 a, mg_company0 b  
		    WHERE b.co_id = a.co_id
		    
		     
          ) AS t
          ORDER BY jumlah_pelamar DESC
	
	
	#23. Tampilkan perusahaan yang tidak memiliki pelamar
	#########soal no 23        
		    SELECT co_name
		    FROM mg_company0 b  
		    WHERE b.co_id NOT IN (
		      SELECT a.co_id
		      FROM mg_jobs0 a
		    
		    )
		    
		    UNION ALL 
		    
			 SELECT  b.co_name 
			FROM   mg_jobs0 a , mg_company0 b
			WHERE a.jobs_id  NOT IN (
			SELECT jobs_id
			FROM mg_jobsl_apply  
			) AND b.co_id = a.co_id
			
			
			
#########ALTER TABLE pegawai
#########ADD UNIQUE (nama_pegawai);			
		     
#########ALTER TABLE jab_pegawai
#########ADD UNIQUE (nama_jab);			
		     
		     
          
    